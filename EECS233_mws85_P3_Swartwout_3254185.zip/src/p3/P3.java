package p3;

import java.io.FileNotFoundException;
import java.io.IOException;

public class P3 
{
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        //Runs wordCount from the wordCount class on the file pg20776.txt
        wordCount.wordCount("pg20776.txt");
    }
}
